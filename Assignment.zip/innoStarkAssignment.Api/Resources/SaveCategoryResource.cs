﻿

namespace innoStarkAssignment.Api.Resources
{
    public class SaveCategoryResource
    {
        public string Name { get; set; }
    }
}
