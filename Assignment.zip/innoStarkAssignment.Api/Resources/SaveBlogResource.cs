﻿namespace innoStarkAssignment.Api.Resources
{
    public class SaveBlogResource
    {
        public string Name { get; set; }
        public int CategoryId { get; set; }
    }
}
